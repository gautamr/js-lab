(function() {
    f();
	
	var f = function() {
	    console.log('I\'m inside f()');
	};
})();
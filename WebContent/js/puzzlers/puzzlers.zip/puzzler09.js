function fun1() {
    return
	{
	    ok: false
	};
}

function fun2() {
    return {
	    ok: false
	};
}
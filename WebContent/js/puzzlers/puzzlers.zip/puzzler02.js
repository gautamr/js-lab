function puzzler02() {
    var n = 10.10;
	var s = n.toString();
	var e = n.toExponential();
	var f = n.toFixed();
	
	alert(s);
	alert(e);
	alert(f);
	
	n.foo = 'JavaScript is very very confusing!!';
	alert(n.foo);
	alert(typeof n);
	alert(typeof s);
	alert(typeof e);
	alert(typeof f);
}
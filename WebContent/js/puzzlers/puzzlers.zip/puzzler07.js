(function() {
    f();
	
	function f() {
	    console.log('I\'m inside f()');
	}
})();
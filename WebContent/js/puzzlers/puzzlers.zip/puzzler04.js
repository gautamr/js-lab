null == undefined
null !== undefined